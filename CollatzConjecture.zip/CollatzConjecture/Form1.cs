﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CollatzConjecture
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Button1_Click(object sender, EventArgs e)
        {
            long number = Convert.ToInt64(startNumber.Text);
            int stepsTaken = 0;
            if (number < 1)
            {
                MessageBox.Show("Nothing would be returned, as your Number is smaller than 1");
            }
            else
            {
                while (number != 1)
                {
                    if (number % 2 == 1)
                    {
                        number = OddNumber(number);
                    }
                    else
                    {
                        number = EvenNumber(number);
                    }
                    stepsTaken++;
                }
                amountOfSteps.Text = stepsTaken.ToString();
            }
        }
        private long OddNumber(long value)
        {
            value = value * 3 + 1;

            return value;
        }
        private long EvenNumber(long value)
        {
            value = value / 2;

            return value;
        }
    }
}
